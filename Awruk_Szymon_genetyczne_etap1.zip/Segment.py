class Segment:
    def __init__(self, direction, length):
        self.direction = direction
        self.length = length



