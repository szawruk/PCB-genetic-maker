class Path:
    def __init__(self):
        self.segments = []



